import sys
import random
from typing import Dict, Set, Tuple
from referee.game.constants import BOARD_N
from referee.game.coord import Coord, Direction
from referee.game.player import PlayerColor
from copy import deepcopy


def get_coords(board: Dict[Coord, PlayerColor], start_color:PlayerColor) -> Set[Coord]:
    """
    Filters all coordinates associated with the color red from the board.
    """

    # Initialize an empty set for storing Coord objects associated with PlayerColor.RED
    start_color_coords = set()

    # Iterate through each item in the board dictionary
    for coord, color in board.items():
        # Check if the color is PlayerColor.RED
        if color == start_color:
            start_color_coords.add(coord)

    # Return the set of coordiantes associated with PlayerColor.RED
    return start_color_coords

def find_valid_adjacent_coords(red_coords: Set[Coord], board: Dict[Coord, PlayerColor]) -> Set[Coord]:
    """
    Finds adjacent coordinates for each coordinate in the re_coords set, where the adjacent 
    coordinate does not exist in the board dictionary.
    """
    
    # Initialize an empty set for storing Coord objects associated with adjacent coords. 
    valid_adjacent_coords = set()

    for coord in red_coords:
        for move in Direction:
            adjacent = coord + move
            # Check if the adjacent coord is not on the board or red_coords set
            if adjacent not in board:
                valid_adjacent_coords.add(adjacent)

    return valid_adjacent_coords

# def build_set_of_tuples_from_coords(valid_adjacent_coords: Set[Coord]) -> Set[Tuple[Coord]]:
#     set_of_tuples = { (coord,) for coord in valid_adjacent_coords }
#     return set_of_tuples

def expand_tuples_with_adjacent_coords(coord_tuples: Set[Tuple[Coord]], board: Dict[Coord, PlayerColor]) -> Set[Tuple[Coord]]:
    """
    For each tuple of Coord objects in a set of tuples, find all adjacent coords that are not
    present in the board dictionary. 
    """

    # Initialize an empty set for storing expanded_coord_tuples associated with adjacent coords.
    expanded_coord_tuples = set()

    for coord_tuple in coord_tuples:
        # Convert the tuples to a set
        existing_coords = set(coord_tuple)

        for coord in coord_tuple:
            for move in Direction:
                adjacent = coord + move

                # Check if the adjacent coordinate is not on the board
                if (adjacent not in board) and (adjacent not in existing_coords):
                    new_coords = set()
                    new_coords.update(existing_coords)
                    new_coords.add(adjacent)

                    # Convert the set back to a tuple and add it to the result set
                    expanded_coord_tuples.add(tuple(new_coords))

    return expanded_coord_tuples

def generate_possible_actions(board: Dict[Coord, PlayerColor], start_color: PlayerColor) -> Set[Tuple[Coord]]:
    """
    Process the game board to calculate actions based on red coordinates.
    Actions are represented as a set of tuples, with each tuple indicating a group 
    of coordinates.
    """
    NUM_OF_ADJACENT_COORDS = 4

    # Get the red coords
    coords = get_coords(board, start_color)

    # Find the valid adjacent coords of the red coords
    valid_adjacent_coords = find_valid_adjacent_coords(coords, board)

    # Make these adjacent coords into a set of tuples
    # coord_tuples = build_set_of_tuples_from_coords(valid_adjacent_coords)
    coord_tuples = { (coord,) for coord in valid_adjacent_coords }

    # Find the 2nd, 3rd, and 4th adjacent coords and save them into coord_tuples
    for _ in range(NUM_OF_ADJACENT_COORDS - 1):  # Repeat the expansion 3 times for 2nd, 3rd, and 4th layers
        coord_tuples = expand_tuples_with_adjacent_coords(coord_tuples, board)

    # Clean up all the duplicate tuples
    cleaned_coord_tuples = {tuple(sorted(set(coord))) for coord in coord_tuples}

    return cleaned_coord_tuples

def eliminate_filled_row_or_column(board: Dict[Coord, PlayerColor]) -> Dict[Coord, PlayerColor]:
    """
    Eliminates a whole row or column from the board if it is completely filled.
    """

    # Initialize sets to keep track of filled rows and columns
    filled_rows = set()
    filled_columns = set()

    # Check each row and column to see if it is filled
    for r in range(BOARD_N):
        if all(Coord(r, c) in board for c in range(BOARD_N)):
            filled_rows.add(r)
    for c in range(BOARD_N):
        if all(Coord(r, c) in board for r in range(BOARD_N)):
            filled_columns.add(c)

    # Eliminate filled rows and columns from the board
    for coord in list(board.keys()):  # Convert to list to avoid RuntimeError for changing dict size during iteration
        if coord.r in filled_rows or coord.c in filled_columns:
            del board[coord]

    return board

def simulate_action(action, board: Dict[Coord, PlayerColor], color: PlayerColor):
    simulated_state = deepcopy(board)

    # Apply each action
    for coord in action:
        simulated_state[coord] = color

    simulated_state = eliminate_filled_row_or_column(simulated_state)

    return simulated_state

def evaluate_and_select(board: Dict[Coord, PlayerColor], possible_actions, color: PlayerColor):
    max_possible_actions = -sys.maxsize
    best_actions = set()

    for action in possible_actions:
        # simulate the action
        simulated_state = simulate_action(action, board, color)

        possible_actions = generate_possible_actions(simulated_state, color)
        num_possible_actions = len(possible_actions)
        
        # Select the action that minimizes the opponent's possible actions
        if num_possible_actions > max_possible_actions:
            max_possible_actions = num_possible_actions
            best_actions.clear()
            best_actions.add(action)
        elif num_possible_actions == max_possible_actions:
            best_actions.add(action)

    return random.choice(list(best_actions))
