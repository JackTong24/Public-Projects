# COMP30024 Artificial Intelligence, Semester 1 2024
# Project Part B: Game Playing Agent

import sys
from typing import Dict
from .actions import ActionNode, eliminate_filled_row_or_column, evaluate_and_select, evaluation_board_with_lookahead, generate_possible_actions, minimax
from referee.game import PlayerColor, Action, PlaceAction, Coord
from referee.game.constants import BOARD_N
import random


class Agent:
    """
    This class is the "entry point" for your agent, providing an interface to
    respond to various Tetress game events.
    """

    def __init__(self, color: PlayerColor, **referee: dict):
        """
        This constructor method runs when the referee instantiates the agent.
        Any setup and/or precomputation should be done here.
        """
        self._color = color
        
        # Initialize the game board representation, a 2D list for instance
        self._board = {}
        self._turn = 0

        match color:
            case PlayerColor.RED:
                print("Testing: I am playing as RED")
            case PlayerColor.BLUE:
                print("Testing: I am playing as BLUE")

    def action(self, **referee: dict) -> Action:
        """
        This method is called by the referee each time it is the agent's turn
        to take an action. It must always return an action object. 
        """

        # Below we have hardcoded two actions to be played depending on whether
        # the agent is playing as BLUE or RED. Obviously this won't work beyond
        # the initial moves of the game, so you should use some game playing
        # technique(s) to determine the best action to take.

        print("time reamining = ", referee["time_remaining"], "space remaining = ", referee["space_remaining"])

        match self._color:
            case PlayerColor.RED:
                print("Testing: RED is playing a PLACE action")
                action = None
                if self._turn == 0:
                    action = PlaceAction(Coord(3, 3), Coord(3, 4), Coord(3, 5), Coord(3, 6))
                    self._turn += 1
                else:
                    possible_actions = generate_possible_actions(self._board, PlayerColor.RED)
                    best_action = random.choice(list(possible_actions))
                    c1, c2, c3, c4 = best_action
                    action = PlaceAction(c1,c2,c3,c4)
                    if action is not None: self._turn += 1
                return action
                
            case PlayerColor.BLUE:
                print("Testing: BLUE is playing a PLACE action")
                action = None
                if self._turn == 0:
                    possible_actions = generate_possible_actions(self._board, PlayerColor.RED)
                    best_action = random.choice(list(possible_actions))
                    c1, c2, c3, c4 = best_action
                    action = PlaceAction(c1,c2,c3,c4)
                    if action is not None: self._turn += 1
                else:
                    possible_actions = generate_possible_actions(self._board, PlayerColor.BLUE)
                    best_action = random.choice(list(possible_actions))
                    c1, c2, c3, c4 = best_action
                    action = PlaceAction(c1,c2,c3,c4)
                    if action is not None: self._turn += 1
                return action

    def update(self, color: PlayerColor, action: Action, **referee: dict):
        """
        This method is called by the referee after an agent has taken their
        turn. You should use it to update the agent's internal game state. 
        """  

        # There is only one action type, PlaceAction
        place_action: PlaceAction = action
        c1, c2, c3, c4 = place_action.coords

        # Place the action
        self._board[c1] = color
        self._board[c2] = color
        self._board[c3] = color
        self._board[c4] = color

        # Check and clear lines
        self._board = eliminate_filled_row_or_column(self._board)

        # Here we are just printing out the PlaceAction coordinates for
        # demonstration purposes. You should replace this with your own logic
        # to update your agent's internal game state representation.
        print(f"Testing: {color} played PLACE action: {c1}, {c2}, {c3}, {c4}")

