import sys
from typing import Dict, Set, Tuple
from referee.game.constants import BOARD_N
from referee.game.coord import Coord, Direction
from referee.game.player import PlayerColor
from copy import deepcopy
import random
import time


def get_coords(board: Dict[Coord, PlayerColor], start_color:PlayerColor) -> Set[Coord]:
    """
    Filters all coordinates associated with the color red from the board.
    """

    # Initialize an empty set for storing Coord objects associated with PlayerColor.RED
    start_color_coords = set()

    # Iterate through each item in the board dictionary
    for coord, color in board.items():
        # Check if the color is PlayerColor.RED
        if color == start_color:
            start_color_coords.add(coord)

    # Return the set of coordiantes associated with PlayerColor.RED
    return start_color_coords

def find_valid_adjacent_coords(red_coords: Set[Coord], board: Dict[Coord, PlayerColor]) -> Set[Coord]:
    """
    Finds adjacent coordinates for each coordinate in the re_coords set, where the adjacent 
    coordinate does not exist in the board dictionary.
    """
    
    # Initialize an empty set for storing Coord objects associated with adjacent coords. 
    valid_adjacent_coords = set()

    for coord in red_coords:
        for move in Direction:
            adjacent = coord + move
            # Check if the adjacent coord is not on the board or red_coords set
            if adjacent not in board:
                valid_adjacent_coords.add(adjacent)

    return valid_adjacent_coords

# def build_set_of_tuples_from_coords(valid_adjacent_coords: Set[Coord]) -> Set[Tuple[Coord]]:
#     set_of_tuples = { (coord,) for coord in valid_adjacent_coords }
#     return set_of_tuples

def expand_tuples_with_adjacent_coords(coord_tuples: Set[Tuple[Coord]], board: Dict[Coord, PlayerColor]) -> Set[Tuple[Coord]]:
    """
    For each tuple of Coord objects in a set of tuples, find all adjacent coords that are not
    present in the board dictionary. 
    """
    # Initialize an empty set for storing expanded_coord_tuples associated with adjacent coords.
    expanded_coord_tuples = set()

    for coord_tuple in coord_tuples:
        # Convert the tuples to a set
        existing_coords = set(coord_tuple)

        for coord in coord_tuple:
            for move in Direction:
                adjacent = coord + move

                # Check if the adjacent coordinate is not on the board
                if (adjacent not in board) and (adjacent not in existing_coords):
                    new_coords = set()
                    new_coords.update(existing_coords)
                    new_coords.add(adjacent)

                    # Convert the set back to a tuple and add it to the result set
                    expanded_coord_tuples.add(tuple(new_coords))

    return expanded_coord_tuples

def generate_possible_actions(board: Dict[Coord, PlayerColor], start_color: PlayerColor) -> Set[Tuple[Coord]]:
    """
    Process the game board to calculate actions based on red coordinates.
    Actions are represented as a set of tuples, with each tuple indicating a group 
    of coordinates.
    """
    NUM_OF_ADJACENT_COORDS = 4

    # Get the red coords
    coords = get_coords(board, start_color)

    # Find the valid adjacent coords of the red coords
    valid_adjacent_coords = find_valid_adjacent_coords(coords, board)

    # Make these adjacent coords into a set of tuples
    # coord_tuples = build_set_of_tuples_from_coords(valid_adjacent_coords)
    coord_tuples = { (coord,) for coord in valid_adjacent_coords }

    # Find the 2nd, 3rd, and 4th adjacent coords and save them into coord_tuples
    for _ in range(NUM_OF_ADJACENT_COORDS - 1):  # Repeat the expansion 3 times for 2nd, 3rd, and 4th layers
        coord_tuples = expand_tuples_with_adjacent_coords(coord_tuples, board)

    # Clean up all the duplicate tuples
    cleaned_coord_tuples = {tuple(sorted(set(coord))) for coord in coord_tuples}

    return cleaned_coord_tuples

def eliminate_filled_row_or_column(board: Dict[Coord, PlayerColor]) -> Dict[Coord, PlayerColor]:
    """
    Eliminates a whole row or column from the board if it is completely filled.
    """

    # Initialize sets to keep track of filled rows and columns
    filled_rows = set()
    filled_columns = set()

    # Check each row and column to see if it is filled
    for r in range(BOARD_N):
        if all(Coord(r, c) in board for c in range(BOARD_N)):
            filled_rows.add(r)
    for c in range(BOARD_N):
        if all(Coord(r, c) in board for r in range(BOARD_N)):
            filled_columns.add(c)

    # Eliminate filled rows and columns from the board
    for coord in list(board.keys()):  # Convert to list to avoid RuntimeError for changing dict size during iteration
        if coord.r in filled_rows or coord.c in filled_columns:
            del board[coord]

    return board

def simulate_action(action, board: Dict[Coord, PlayerColor], color: PlayerColor):
    simulated_state = deepcopy(board)

    # Apply each action
    for coord in action:
        simulated_state[coord] = color

    simulated_state = eliminate_filled_row_or_column(simulated_state)

    return simulated_state

def evaluate_and_select(board: Dict[Coord, PlayerColor], possible_actions, color: PlayerColor):
    min_opponent_actions = sys.maxsize
    best_actions = set()

    for action in possible_actions:
        # simulate the action
        simulated_state = simulate_action(action, board, color)

        # determine opponent's possible actions from this state
        opponent_color = PlayerColor.RED if color == PlayerColor.BLUE else PlayerColor.BLUE
        opponent_actions = generate_possible_actions(simulated_state, opponent_color)
        num_opponent_actions = len(opponent_actions)
        
        # Select the action that minimizes the opponent's possible actions
        if num_opponent_actions < min_opponent_actions:
            min_opponent_actions = num_opponent_actions
            best_actions.clear()
            best_actions.add(action)
        elif num_opponent_actions == min_opponent_actions:
            best_actions.add(action)

    return random.choice(list(best_actions))

class ActionNode:
    def __init__(self, action, parent = None, score = 0):
        self.action = action
        self.parent = parent
        self.children = []
        # score = the number of possible actions if the current action is implemented.
        self.score = score
    
    def add_child(self, child_node):
        # Method to add a child node to the children list
        self.children.append(child_node)
        child_node.parent = self

    def trace_back_initial_action(self):
        # Trace back to the root node's action
        current = self
        while current.parent is not None:
            current = current.parent
        return current.action
    
def minimax(node: ActionNode, depth: int, alpha: int, beta: int, is_maximizing_player: bool):
    # Base case: if we reach a leaf node or the maximum depth
    if depth == 0 or not node.children:
        return node.score, node.action
    
    best_actions = set()
    
    if is_maximizing_player:
        # Maximizing player tries to get the maximum score 
        max_eval = -sys.maxsize
        for child in node.children:
            eval, action = minimax(child, depth - 1, alpha, beta, False)
            if eval > max_eval:
                max_eval = eval
                best_actions = {child.action if node.children else None}
            elif eval == max_eval:
                best_actions.add(child.action if node.children else None)
            alpha = max(alpha, eval)
            if alpha >= beta:
                break
        node.score = max_eval

        return max_eval, random.choice(list(best_actions))

    else:
        # Minimizing player tries to get the minimum score
        min_eval = sys.maxsize
        for child in node.children:
            eval,_ = minimax(child, depth - 1, alpha, beta, True)
            if eval < min_eval:
                min_eval = eval
                best_actions = {child.action if node.children else None}
            elif eval == min_eval:
                best_actions.add(child.action if node.children else None)
            beta = min(beta, eval)
            if alpha >= beta:
                break
        node.score = min_eval
        
        return min_eval, random.choice(list(best_actions))
        # if best_actions:
        #     return  min_eval, sorted(list(best_actions))[0]
        # else:
        #     return None

def evaluation_board_with_lookahead(board: Dict[Coord, PlayerColor], color: PlayerColor, depth, parent_node = None):       
    # base case
    if depth == 0:
        return
    
    opponent_color = PlayerColor.RED if color == PlayerColor.BLUE else PlayerColor.BLUE
    min_score = sys.maxsize
    action_nodes = []

    # Generate possible actions for the current player
    possible_actions = generate_possible_actions(board, color)

    # If there is no futher action, assign the parent_node.score = 0
    if len(possible_actions) == 0:
        parent_node.score = 0
        return

    # Generate action nodes and find the minimal score among them
    for action in possible_actions:
        simulated_state = simulate_action(action, board, color)
        
        # Generate opponent's possible responses
        opponent_actions = generate_possible_actions(simulated_state, opponent_color)
        num_opponent_actions = len(opponent_actions)

        # Creat the current_node
        current_node = ActionNode(action, parent_node, num_opponent_actions)

        # Collect nodes and find the minimal score
        action_nodes.append(current_node)
        min_score = min(min_score, num_opponent_actions)
    
    # print("min_score =", min_score)
    
    # Link nodes with the minimal score to the parent node and explore further
    # BRANCHING_THRESHOLD control the maximum branching factor
    # BRANCHING_THRESHOLD = 3
    # count = 0
    for node in action_nodes:
        if node.score == min_score:
            # count += 1
            # Every layer do not explore more than BRANCHING_THRESHOLD number of equivalent notes.
            # if count > BRANCHING_THRESHOLD:
            #     break
            parent_node.add_child(node)
            # Recursively call this function only for nodes with minimal scores
            if depth > 1:
                # print("go the depth = ", depth)
                simulated_state = simulate_action(node.action, board, color)
                evaluation_board_with_lookahead(simulated_state, opponent_color, depth-1, node)

    return
