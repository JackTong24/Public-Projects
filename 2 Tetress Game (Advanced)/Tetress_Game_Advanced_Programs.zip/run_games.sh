#!/bin/bash

# File to store the results
output_file="results.txt"

# Clear the output file if it already exists
> $output_file

# Function to handle the interrupt signal
function on_interrupt {
    echo "Script interrupted. Partial results are stored in $output_file"
    exit 1
}

# Trap the interrupt signal (Ctrl+C)
trap on_interrupt SIGINT

# Run the command n times
for i in {1..20}
do
    echo "Running game $i" >> $output_file
    python -m referee agent_random agent -s 250 -t 180 >> $output_file
    echo "" >> $output_file  # Add a newline for better readability
done

echo "All games completed. Results are stored in $output_file"